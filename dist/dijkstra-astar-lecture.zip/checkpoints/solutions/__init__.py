"""Runnable checkpoint solutions."""
